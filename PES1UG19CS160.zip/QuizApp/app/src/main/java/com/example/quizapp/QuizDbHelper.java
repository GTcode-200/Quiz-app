package com.example.quizapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.quizapp.QuizContract.*;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;


public class QuizDbHelper extends SQLiteOpenHelper //provides layer between sqlite database and activity class
{
    private static final String DATABASE_NAME = "Quiz.db"; //Quiz.db->database To store questions,options,answers
    private static final int DATABASE_VERSION = 1;//first version of the app
    private SQLiteDatabase db;
    public QuizDbHelper(Context context) //pass context to this constructor in Quizactivity.java while creating db object
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION); // pass the parameters to super class for creating the database
    }
    @Override
    public void onCreate(SQLiteDatabase db) { //called when database is created for the first time
        this.db = db;
        final String SQL_CREATE_QUESTIONS_TABLE = "CREATE TABLE " +
                QuestionsTable.TABLE_NAME + " ( " +
                QuestionsTable._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                QuestionsTable.COLUMN_QUESTION + " TEXT, " +
                QuestionsTable.COLUMN_OPTION1 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION2 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION3 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION4 + " TEXT, " +
                QuestionsTable.COLUMN_ANSWER_NR + " INTEGER, " +
                QuestionsTable.COLUMN_CATEGORY + "  TEXT "+
                ")"; //Sql query is stored to create a table
        db.execSQL(SQL_CREATE_QUESTIONS_TABLE);//executes single sql statement without returning anything
        fillQuestionsTable();
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + QuestionsTable.TABLE_NAME);
        onCreate(db);//create new database
    }
    private void fillQuestionsTable() {

        Question q1 = new Question("Two sources are said to be coherent if they produce waves",
                "having a constant phase difference",
                "of equal wavelength",
                "of equal speed",
                "having same shape of wavefront",1,Question.CATEGORY_PHYSICS);
        addQuestion(q1);

        Question q2 = new Question("Waves that cannot be polarised are:",
                "electromagnetic waves",
                "lightwaves",
                "longitudinal waves",
                "transverse waves",3,Question.CATEGORY_PHYSICS);
        addQuestion(q2);

        Question q3 = new Question("The material used for permanent magnet has:",
                "low retentivity,high coercivity",
                "high retentivity,low coercivity",
                "high retentivity,high coercivity",
                "low retentivity,low coercivity",3,Question.CATEGORY_PHYSICS);
        addQuestion(q3);

        Question q4 = new Question("The ratio of velocity of sound in hydrogen and oxygen at stp is:",
                "16:1",
                "4:1",
                "8:1",
                "2:1",2,Question.CATEGORY_PHYSICS);
        addQuestion(q4);

        Question q5 = new Question("If the forward voltage in a diode is increased,the width of the depletion region:",
                "increases",
                "decreases",
                "fluctuates",
                "no change",2,Question.CATEGORY_PHYSICS);
        addQuestion(q5);

        Question q6 = new Question("If a liquid does not wet glass,its angle of contact is:",
                "acute",
                "right angle",
                "zero",
                "obtuse",4,Question.CATEGORY_PHYSICS);
        addQuestion(q6);

        Question q7 = new Question("The disc of a siren containing 60 holes rotates at a constant speed of 360 rpm.The emitted sound is in unison with a tuning fork of frequency:",
                "10 Hz",
                "360 Hz",
                "216 Hz",
                "60 Hz",2,Question.CATEGORY_PHYSICS);
        addQuestion(q7);

        Question q8 = new Question("Infrared radiation was discovered in 1800 by:",
                "William Wollaston",
                "William Herschel",
                "Wilhelm Roentgen",
                "Thomas Young",2,Question.CATEGORY_PHYSICS);
        addQuestion(q8);

        Question q9 = new Question("Mean life of a radioactive sample is 100 seconds.Then its haf-life(in minutes) is",
                "0.693",
                "1",
                "0.0001",
                "1.155",4,Question.CATEGORY_PHYSICS);
        addQuestion(q9);

        Question q10 = new Question("The induction coil works on the principle of :",
                "Mutual induction",
                "Self induction",
                "Ampere's rule",
                "Fleming's right hand rule",1,Question.CATEGORY_PHYSICS);
        addQuestion(q10);

        Question q11 = new Question("In chromite ore ,the oxidation number of iron, and chromium are respectively:",
                "+3,+2",
                "+3,+6",
                "+2,+6",
                "+2,+3",4,Question.CATEGORY_CHEMISTRY);
        addQuestion(q11);

        Question q12 = new Question("In the electrolyte refining of zinc ",
                "graphite is at the anode",
                "the impure metal is at the cathode",
                "the metal ion get reduced at the anode",
                "acidified zinc sulphate is the electrolyte",1,Question.CATEGORY_CHEMISTRY);
        addQuestion(q12);

        Question q13 = new Question("The set of quantum numbers for the outermost electron for copper in its ground state is",
                "4,1,1,+1/2",
                "3,2,2,+1/2",
                "4,0,0,+1/2",
                "4,2,2,+1/2",3,Question.CATEGORY_CHEMISTRY);
        addQuestion(q13);

        Question q14 = new Question("Which one of the following is an example for homogeneous catalysis",
                "Manufacture of sulphuric acid by Contact process",
                "Manufacture of ammonia by Haber's process",
                "Hydrolysis of sucrose in presence of dilute hydrochlorc acid",
                "Hydrogenation of oil",3,Question.CATEGORY_CHEMISTRY);
        addQuestion(q14);

        Question q15 = new Question("The letter 'D' in D-glucose signifies ",
                "configuration at all chiral carbons",
                "dextrorotatory",
                "that is monosaccharide",
                "confiuration at a particular chiral carbon",4,Question.CATEGORY_CHEMISTRY);
        addQuestion(q15);

        Question q16 = new Question("Which one of the following is a molecular crystal?",
                "Rock salt",
                "Quartz",
                "Dry ice",
                "Diamond",3,Question.CATEGORY_CHEMISTRY);
        addQuestion(q16);

        Question q17 = new Question("Chloroacetic acid is a stronger acid than acetic acid.This can be explained using",
                "-M effect",
                "+M effect",
                "-I effect",
                "+I effect",3,Question.CATEGORY_CHEMISTRY);
        addQuestion(q17);

        Question q18 = new Question("Benzaldehyde and acetone can be best distinguished using ",
                "Fehling's solution",
                "Sodium hydroxide solution",
                "2,4-DNP ",
                "Tollen's reagent",4,Question.CATEGORY_CHEMISTRY);
        addQuestion(q18);

        Question q19 = new Question("Reaction of methyl bromide with aqueous sodium hydroxide involves",
                "racemisation",
                "SN1 mechanism",
                "SN2 mechanism",
                "retention of configuration",3,Question.CATEGORY_CHEMISTRY);
        addQuestion(q19);

        Question q20 = new Question("Which of the following statements is true?",
                "Saponificaton of oil yields a diol",
                "Drying of oil involves hydrolysis",
                "Addition of antioxidant to oil minimizes rancidity",
                "Refining of oil involves hydrogenation",3,Question.CATEGORY_CHEMISTRY);
        addQuestion(q20);

        Question q21 = new Question("The foot of the perpendicular from the point (2,4) upon x+y=4 is",
                "(2,2)",
                "(4,0)",
                "(1,3)",
                "(3,-1)",3,Question.CATEGORY_MATHS);
        addQuestion(q21);

        Question q22 = new Question("The vertices of a triangle are (6,0),(0,6) and (6,6).The distance between its circumcentre and centroid is",
                "2",
                "√2",
                "1",
                "2√2",2,Question.CATEGORY_MATHS);
        addQuestion(q22);

        Question q23 = new Question("The coordinates of the centre of the smallest circle passing through the origin and having y=x+1 as a diameter are",
                "(1/2,-1/2)",
                "(1/2,1/3)",
                "(-1,0)",
                "(-1/2,1/2)",4,Question.CATEGORY_MATHS);
        addQuestion(q23);

        Question q24 = new Question("If ax+by=1,where a,b,x and y are integers,then which one of the following is not true?",
                "(a,y)=1",
                "(x,y)=1",
                "(b,y)=1",
                "(a,b)=1",3,Question.CATEGORY_MATHS);
        addQuestion(q24);

        Question q25 = new Question("(0,-1) and (0,3) are two opposite vertices of a square.The other two vertices are:",
                "(0,1),(0,-3)",
                "(3,-1),(0,0)",
                "(2,1),(-2,1)",
                "(2,2),(1,1)",3,Question.CATEGORY_MATHS);
        addQuestion(q25);

        Question q26 = new Question("In the group {0,1,2,4,5} under addition modulo 6 a subgroup is:",
                "{0,2,5}",
                "{1,4,5}",
                "{0,1,3}",
                "{0,2,4}",4,Question.CATEGORY_MATHS);
        addQuestion(q26);

        Question q27 = new Question("The digit in the units place of 7²⁸⁹ is:",
                "9",
                "7",
                "1",
                "3",2,Question.CATEGORY_MATHS);
        addQuestion(q27);

        Question q28 = new Question("The circum-radius of the triangle whose sides are 13,12 and 5 is:",
                "15",
                "13/2",
                "15/2",
                "6",2,Question.CATEGORY_MATHS);
        addQuestion(q28);

        Question q29 = new Question("The converse of the contrapositve of p->q is:",
                "~p->q",
                "p->~q",
                "~p->~q",
                "~q->p",3,Question.CATEGORY_MATHS);
        addQuestion(q29);

        Question q30 = new Question("The centre of the circle x= 2 + 3 cosθ ,y=3sinθ-1 is :",
                "(3,3)",
                "(2,-1)",
                "(-2,1)",
                "(-1,2)",2,Question.CATEGORY_MATHS);
        addQuestion(q30);



    }
    private void addQuestion(Question question) {
        ContentValues cv = new ContentValues(); // allows key-value to be declared consisting of table of column identifiers and the values to be stored in each column
        cv.put(QuestionsTable.COLUMN_QUESTION, question.getQuestion());//adds the value to the set
        cv.put(QuestionsTable.COLUMN_OPTION1, question.getOption1());
        cv.put(QuestionsTable.COLUMN_OPTION2, question.getOption2());
        cv.put(QuestionsTable.COLUMN_OPTION3, question.getOption3());
        cv.put(QuestionsTable.COLUMN_OPTION4, question.getOption4());
        cv.put(QuestionsTable.COLUMN_ANSWER_NR, question.getAnswerNr());
        cv.put(QuestionsTable.COLUMN_CATEGORY, question.getCategory());

        db.insert(QuestionsTable.TABLE_NAME, null, cv);//inserts the set into table
    }
   /* public List<Question> getAllQuestions() {
        List<Question> questionList = new ArrayList<>();//List generic to store thelist of questions

        db = getReadableDatabase();//opens database
        Cursor c = db.rawQuery("SELECT * FROM " + QuestionsTable.TABLE_NAME, null);//executes sql query and returns cursor object
        if (c.moveToFirst()) {
            do {
                Question question = new Question();
                question.setQuestion(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_QUESTION)));
                question.setOption1(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION1)));
                question.setOption2(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION2)));
                question.setOption3(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION3)));
                question.setOption3(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION4)));
                question.setAnswerNr(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_ANSWER_NR)));
                question.setCategory(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_CATEGORY)));
                questionList.add(question);
            } while (c.moveToNext());
        }
        c.close(); // close the database
        return questionList;
    }*/

    public List<Question> getQuestions(String category) {
        List<Question> questionList = new ArrayList<>();//List generic to store thelist of questions

        db = getReadableDatabase();//opens database

        String[] selectionArgs = new String[]{category};
        Cursor c = db.rawQuery("SELECT * FROM " + QuestionsTable.TABLE_NAME + " WHERE "+ QuestionsTable.COLUMN_CATEGORY + " = ?",selectionArgs );//executes sql query and returns cursor object
        if (c.moveToFirst()) {
            do {
                Question question = new Question();
                question.setQuestion(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_QUESTION)));
                question.setOption1(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION1)));
                question.setOption2(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION2)));
                question.setOption3(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION3)));
                question.setOption4(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION4)));
                question.setAnswerNr(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_ANSWER_NR)));
                question.setCategory(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_CATEGORY)));

                questionList.add(question);
            } while (c.moveToNext());
        }
        c.close(); // close the database
        return questionList;
    }
}
