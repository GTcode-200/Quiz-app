package com.example.quizapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ScoreActivity extends AppCompatActivity
{
    private TextView score;
    private Button home_screen;
    private TextView result_score;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);

        score= findViewById(R.id.final_score);

        Intent scoreIntent = getIntent();
        int finalScore=scoreIntent.getIntExtra(QuizActivity.EXTRA_SCORE,0);
        score.setText("Your Score : "+ finalScore +"/10");
        display_result(finalScore);
        home_screen = findViewById(R.id.goHome);

        home_screen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                //homeScreen();
                finish();
            }
        });

    }

   /* private void homeScreen()
    {
        //Intent homeIntent = new Intent(ScoreActivity.this,MainActivity.class);
        finish();
        // startActivity(homeIntent);

    }
*/


    private void display_result(int score)
    {   result_score=findViewById(R.id.result);
        if(score>=0 && score<5)
            result_score.setText("Your score is very less.You need to go through the concepts again");
        else if(score>=5 && score<8)
            result_score.setText("Good attempt.But you need to revise the concepts again");
        else if(score>=8)
            result_score.setText("Well done.Keep it up!!!!");
    }
    }

